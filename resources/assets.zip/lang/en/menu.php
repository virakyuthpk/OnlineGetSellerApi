<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Pagination Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the paginator library to build
    | the simple pagination links. You are free to change them to anything
    | you want to customize your views to better match your application.
    |
    */
    // Menu
    
    'contact info' => 'CONTACT Us',
    'sale' => 'Sell On Onlineget',
    'home' => 'Home',
    'about' => 'About',
    'contact' => 'Contact Us',
    'login' => 'Login',
    'register' => 'Register',
    'product' => 'Product',
    'How To Buy' => 'How To Buy',
    'Delivery Information' => 'Delivery Information',
    'Returns Policy' => 'Returns Policy',
    'Returns' => 'Returns',
    'My Account' => 'My Account',
    'Order History' => 'Order History',
    'My account' => 'My Account',
    'Customer Service' => 'Customer Service',
    'Career' => 'Career',
    'Ship Calculator' => 'Ship Calculator',
    'Wish List' =>'Wish List',
    'Newsletter' => 'Newsletter',
    'en' => 'English',
    'kh' => 'Khmer',
    'OUR FACEBOOK PAGE' => 'OUR FACEBOOK PAGE',
    'GET THE APP' => 'GET THE APP',
    'Category' => 'Category',
    'My cart' => 'Cart',
];
