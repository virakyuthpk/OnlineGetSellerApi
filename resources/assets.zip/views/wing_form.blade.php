 <!--<form action="{{action('PaymentController@store')}}" method='POST'> -->

<form action="https://wingsdk.wingmoney.com:334" method="POST">
            <input name="ask_remember" type="text" value="0">
            <input name="sandbox" type="text" value="1">
            <input name="amount" type="text" id="amount">
            <input name="username" type="text" value="online.bungech">
            <input name="rest_api_key" type="text" value="c97ef9524653ae24a660b3910f7f8de98addc6470aa3ddaa4e5253b3c8707c52">
            <input name="return_url" type="hidden" value="https://www.onlineget.com/api/form">
            <input name="bill_till_rbtn" type="text" value="0">
            <input name="bill_till_number" type="text" value="5102">
            <input name="pay" type="submit" value="Pay">          
</form>


<!--<form action="https://wingsdk.wingmoney.com:334/" method='POST'>-->
<!--	<div>-->
<!--		<label for="user_name">Username:</label> -->
<!--		<input name="username" type="text" placeholder="Username" />-->
<!--	</div>-->
<!--	<div> -->
<!--		<input checked="checked" name="bill_till_rbtn" type="radio" value="1" /> Bill Number -->
<!--		<input name="bill_till_rbtn" type="radio" value="0" /> Till Number -->
<!--		<input name="bill_till_number" type="text" placeholder="Bill or Till Number" />-->
<!--	</div>-->
<!--	<div> -->
<!--		<input checked="checked" name="sandbox" type="checkbox" value="1" /> Sandbox -->
<!--	</div>-->
<!--	<div>-->
<!--		<label for="bill_number">Rest API Key:</label> -->
<!--		<input style="width: 800px;" name="rest_api_key" type="text" placeholder="rest_api_key" />-->
<!--	</div>-->
<!--	<div>-->
<!--		<label for="wing_account">Wing Account:</label> -->
<!--		<input name="wing_account" type="text" placeholder="Wing Account" />-->
<!--	</div>-->
<!--	<div>-->
<!--		<label for="DOB">DOB:</label> -->
<!--		<input name="DOB" type="text" placeholder="DOB" />-->
<!--	</div>-->
<!--	<div>-->
<!--		<label for="PIN">PIN:</label> -->
<!--		<input name="PIN" type="text" placeholder="PIN" />-->
<!--	</div>-->
<!--	<div>-->
<!--		<label for="amount">Amount:</label> -->
<!--		<input name="amount" type="text" placeholder="Amount" />-->
<!--	</div>-->
<!--	<div>-->
<!--		<div>-->
<!--			<label for="attr1_name">Attribute Name 1:</label> -->
<!--			<input name="attr1_name" type="text" placeholder="Attribute Name 1" />-->
<!--		</div>-->
<!--		<div>-->
<!--			<label for="attr1_value">Attribute Value 1:</label> -->
<!--			<input name="attr1_value" type="text" placeholder="Attribute Value 1" />-->
<!--		</div>-->
<!--	</div>-->
<!--	<div>-->
<!--		<div>-->
<!--			<label for="attr2_name">Attribute Name 2:</label> -->
<!--			<input name="attr2_name" type="text" placeholder="Attribute Name 2" />-->
<!--		</div>-->
<!--		<div>-->
<!--			<label for="attr2_value">Attribute Value 2:</label> -->
<!--			<input name="attr2_value" type="text" placeholder="Attribute Value 2" />-->
<!--	</div>-->
<!--	</div>-->
<!--	<div>-->
<!--		<label for="return_url">Return URL:</label> -->
<!--		<input name="return_url" type="text" placeholder="Return URL" />-->
<!--	</div>-->
<!--	<div>-->
<!--		<label for="remark">Remark:</label> -->
<!--		<input name="remark" type="text" placeholder="Remark" />-->
<!--	</div>-->
<!--	<div>-->
<!--		<input name="default_wing" type="checkbox" value="1" /> Default Wing -->
<!--		<input name="remember_card" type="checkbox" value="0" /> Remember Card-->
<!--	</div>-->
<!--	<input name="pay" type="submit" value="Pay" />-->

<!--</form>-->
