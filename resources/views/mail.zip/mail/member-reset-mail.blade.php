Hello.<br><br>

You recently requested to reset your password <br><br>

Here is the code for confirm <b>{!!$token!!}</b>
