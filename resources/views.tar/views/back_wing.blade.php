@extends('front.joinus.layout')
@section('content')
<div style="color: green;text-align: center; margin:25px;">
    <h3 >Your payment is completely successful!!!</h3>
    <a href="https://onlineget.com" class="btn btn-primary"> Back to Home </a>
</div>


@endsection