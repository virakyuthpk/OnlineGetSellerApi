<section class="footer-bottom ">
	<div class="container">
	    <div class="row">
	        <div class="col-lg-6 col-md-7 col-sm-12 col-xs-12 copyright-w">
	            <div class="copyright">© 2018 Onlineget. All Rights Reserved.
	            </div>
	        </div>
	        <div class="col-lg-6 col-md-5 col-sm-12 col-xs-12 payment-w">
	            <!-- <img src="{!!asset('front/image/catalog/demo/payment/payment-4.png') !!}" alt="imgpayment"> -->
	        </div>
	    </div>
	</div>
</section>
<div class="back-to-top"><i class="fa fa-angle-up"></i></div>