

<!DOCTYPE html>
<html lang="en">
<head>
    <title>GECH CHOU Import Export</title>
    <meta charset="utf-8">
    <meta name="keywords" content="html5 template, best html5 template, best html template, html5 basic template, multipurpose html5 template, multipurpose html template, creative html templates, creative html5 templates" />
    <meta name="description" content="eMarket is a powerful Multi-purpose HTML5 Template with clean and user friendly design. It is definite a great starter for any eCommerce web project." />
    <meta name="author" content="Phsar tech">
    <meta name="robots" content="index, follow" />
   
    <!-- Mobile specific metas
    ============================================ -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <!-- Favicon
    ============================================ -->
    <link rel="shortcut icon" type="image/png" href="ico/favicon-16x16.png"/>
    <!-- Libs CSS
    ============================================ -->
    {!! Html::style('front/css/bootstrap/css/bootstrap.min.css') !!}
    {!! Html::style('front/css/font-awesome/css/font-awesome.min.css') !!}
    {!! Html::style('front/js/datetimepicker/bootstrap-datetimepicker.min.css') !!}
    {!! Html::style('front/js/owl-carousel/owl.carousel.css') !!}
    {!! Html::style('front/css/themecss/lib.css') !!}
    {!! Html::style('front/js/jquery-ui/jquery-ui.min.css') !!}
    {!! Html::style('front/js/minicolors/miniColors.css') !!}
    {!! Html::style('front/css/custom.css') !!}
    <!-- Theme CSS
    ============================================ -->
    {!! Html::style('front/css/themecss/so_searchpro.css') !!}
    {!! Html::style('front/css/themecss/so_megamenu.css') !!}
    {!! Html::style('front/css/themecss/so-categories.css') !!}
    {!! Html::style('front/css/themecss/so-listing-tabs.css') !!}
    {!! Html::style('front/css/themecss/so-newletter-popup.css') !!}
    
    {!! Html::style('front/css/footer/footer1.css') !!}
    {!! Html::style('front/css/header/header1.css') !!}
    {!! Html::style('front/css/theme.css') !!}
    {!! Html::style('front/css/responsive.css') !!}
     <!-- Google web fonts
    ============================================ -->
    <link href='https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,500i,700' rel='stylesheet' type='text/css'>
</head>
<body class="common-home res layout-1">
    <div id="wrapper" class="wrapper-fluid banners-effect-5">
        <header id="header" class=" typeheader-1">
            <div class="header-top hidden-compact">
                <div class="container">
                    <div class="row">
                        <div class="header-top-left col-lg-7 col-md-8 col-sm-6 col-xs-4">
                            <div class="hidden-sm hidden-xs welcome-msg">

                                <i class="fa fa-phone"></i> (+123)4 567 890
                                <i class="fa fa-envelope-open "></i> h.sreyet@gmail.com
                            </div>
                                      
                        </div>
                        <div class="header-top-right collapsed-block col-lg-5 col-md-4 col-sm-6 col-xs-8">
                            <ul class="top-link list-inline lang-curr">
                                <li class="currency">
                                    <div class="btn-group currencies-block">
                                        <form action="http://demo.smartaddons.com/templates/html/emarket/index.php" method="post" enctype="multipart/form-data" id="currency">
                                            <a class="btn btn-link dropdown-toggle" data-toggle="dropdown">
                                               <i class="fa fa-user"></i>  Loging /Register  <span class="fa fa-angle-down"></span>
                                            </a>
                                            <ul class="dropdown-menu btn-xs">
                                                <li> <a href="#">Login</a></li>
                                                <li> <a href="#">Register</a></li>
                                            </ul>
                                        </form>
                                    </div>
                                </li>   
                                <li class="language">
                                    <div class="btn-group languages-block ">
                                        <form action="http://demo.smartaddons.com/templates/html/emarket/index.php" method="post" enctype="multipart/form-data" id="bt-language">
                                            <a class="btn btn-link dropdown-toggle" data-toggle="dropdown">
                                                <img src="{!!asset('front/image/catalog/flags/en.png') !!}" alt="English" title="English">
                                                <span class="">English</span>
                                                <span class="fa fa-angle-down"></span>
                                            </a>
                                            <ul class="dropdown-menu">
                                                <li><a href="index.html"><img class="image_flag" src="{!!asset('front/image/catalog/flags/en.png') !!}" alt="English" title="English" /> English </a></li>
                                                <li> <a href="index.html"> <img class="image_flag" src="{!!asset('front/image/catalog/flags/kh.png') !!}" alt="Arabic" title="Arabic" /> Khmer</a> </li>
                                            </ul>
                                        </form>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- //Header Top -->
            <!-- Header center -->
            <div class="header-middle">
                <div class="container">
                    <div class="row">
                        <!-- Logo -->
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <div class="navbar-logo">
                                <div class="logo">
                                    <a href="index.html">
                                        <img src="{!!asset('front/images/logo.png') !!}" title="Your Store" alt="Your Store" />
                                    </a>
                                </div>
                            </div>
                        </div>
                        <!-- //end Logo -->
                        <!-- Main menu -->
                        <div class="col-lg-6 col-md-6">
                            <div class="main-menu">
                                <div class="responsive so-megamenu megamenu-style-dev">
                                     <img src="{!!asset('front/images/banner7.png') !!}" title="Your Store" alt="Your Store" />
                                    <!-- <nav class="navbar-default">
                                        <div class=" container-megamenu  horizontal open ">
                                            <div class="navbar-header">
                                                <button type="button" id="show-megamenu" data-toggle="collapse" class="navbar-toggle">
                                                    <span class="icon-bar"></span>
                                                    <span class="icon-bar"></span>
                                                    <span class="icon-bar"></span>
                                                </button>
                                            </div>
                                            <div class="megamenu-wrapper">
                                                <span id="remove-megamenu" class="fa fa-times"></span>
                                                <div class="megamenu-pattern">
                                                    <div class="container-mega">
                                                        <ul class="megamenu" data-transition="slide" data-animationtime="250">
                                                            <li class="home hover">
                                                                <a href="index.html">Home</a>
                                                            </li>
                                                            <li>
                                                                <a href="#">About</a>
                                                            </li>
                                                            <li>
                                                                <a href="#">Products</a>
                                                            </li>
                                                            <li>
                                                                <a href="#">Contact</a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </nav> -->
                                </div>
                            </div>   
                        </div>
                    </div>
                </div>
            </div>
            <!-- //Header center -->
            <!-- Header Bottom -->
             <div class="header-bottom hidden-compact">
                <div class="container">
                    <div class="row">
                        <div class="bottom1 menu-vertical col-lg-2 col-md-3 col-sm-3">
                            <div class="responsive so-megamenu megamenu-style-dev ">
                                <div class="so-vertical-menu ">
                                    <nav class="navbar-default">    
                                        <div class="container-megamenu vertical">
                                            <div id="menuHeading">
                                                <div class="megamenuToogle-wrapper">
                                                    <div class="megamenuToogle-pattern">
                                                        <div class="container">
                                                            <div>
                                                                <span></span>
                                                                <span></span>
                                                                <span></span>
                                                            </div>
                                                            All Categories                          
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="navbar-header">
                                                <button type="button" id="show-verticalmenu" data-toggle="collapse" class="navbar-toggle">      
                                                    <i class="fa fa-bars"></i>
                                                    <span>  All Categories</span>
                                                </button>
                                            </div>
                                            <div class="vertical-wrapper" >
                                                <span id="remove-verticalmenu" class="fa fa-times"></span>
                                                <div class="megamenu-pattern">
                                                    <div class="container-mega">
                                                        <ul class="megamenu">
                                                            <li class="item-vertical  with-sub-menu hover">
                                                                <p class="close-menu"></p>
                                                                <a href="#" class="clearfix">
                                                                    <img src="{!!asset('front/image/catalog/menu/icons/ico10.png') !!}" alt="icon">
                                                                    <span>Gifts & Toys</span>
                                                                    <b class="caret"></b>
                                                                </a>
                                                                <div class="sub-menu" data-subwidth="60"  >
                                                                    <div class="content" >
                                                                        <div class="row">
                                                                            <div class="col-sm-12">
                                                                                <div class="row">
                                                                                    <div class="col-md-4 static-menu">
                                                                                        <div class="menu">
                                                                                            <ul>
                                                                                                <li>
                                                                                                    <a href="#"  class="main-menu">Apparel</a>
                                                                                                    <ul>
                                                                                                        <li><a href="#" >Accessories for Tablet PC</a></li>
                                                                                                        <li><a href="#" >Accessories for i Pad</a></li>
                                                                                                        <li><a  href="#" >Accessories for iPhone</a></li>
                                                                                                        <li><a href="#" >Bags, Holiday Supplies</a></li>
                                                                                                        <li><a href="#" >Car Alarms and Security</a></li>
                                                                                                        <li><a href="#" >Car Audio &amp; Speakers</a></li>
                                                                                                    </ul>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <a href="#"  class="main-menu">Cables &amp; Connectors</a>
                                                                                                    <ul>
                                                                                                        <li><a href="#" >Cameras &amp; Photo</a></li>
                                                                                                        <li><a href="#" >Electronics</a></li>
                                                                                                        <li><a href="#" >Outdoor &amp; Traveling</a></li>
                                                                                                    </ul>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col-md-4 static-menu">
                                                                                        <div class="menu">
                                                                                            <ul>
                                                                                                <li>
                                                                                                    <a href="#"  class="main-menu">Camping &amp; Hiking</a>
                                                                                                    <ul>
                                                                                                        <li><a href="#" >Earings</a></li>
                                                                                                        <li><a href="#" >Shaving &amp; Hair Removal</a></li>
                                                                                                        <li><a href="#" >Salon &amp; Spa Equipment</a></li>
                                                                                                    </ul>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <a href="#" class="main-menu">Smartphone &amp; Tablets</a>
                                                                                                    <ul>
                                                                                                        <li><a href="#" >Sports &amp; Outdoors</a></li>
                                                                                                        <li><a href="#" >Bath &amp; Body</a></li>
                                                                                                        <li><a href="#" >Gadgets &amp; Auto Parts</a></li>
                                                                                                    </ul>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col-md-4 static-menu">
                                                                                        <div class="menu">
                                                                                            <ul>
                                                                                                <li>
                                                                                                    <a href="#"  class="main-menu">Bags, Holiday Supplies</a>
                                                                                                    <ul>
                                                                                                        <li><a href="#" onclick="window.location = '18_46.html';">Battereries &amp; Chargers</a></li>
                                                                                                        <li><a href="#" onclick="window.location = '24_64.html';">Bath &amp; Body</a></li>
                                                                                                        <li><a href="#" onclick="window.location = '18_45.html';">Headphones, Headsets</a></li>
                                                                                                        <li><a href="#" onclick="window.location = '18_30.html';">Home Audio</a></li>
                                                                                                    </ul>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="item-vertical">
                                                                <p class="close-menu"></p>
                                                                <a href="#" class="clearfix">
                                                                    <img src="{!!asset('front/image/catalog/menu/icons/ico1.png') !!}" alt="icon">
                                                                    <span>Fashion & Accessories</span>
                                                                    
                                                                </a>
                                                            </li>
                                                            <li class="item-vertical  style1 with-sub-menu hover">
                                                                <p class="close-menu"></p>
                                                                <a href="#" class="clearfix">
                                                                    <span class="label"></span>
                                                                    <img src="{!!asset('front/image/catalog/menu/icons/ico9.png') !!}" alt="icon">
                                                                    <span>Electronic</span>
                                                                     
                                                                    <b class="caret"></b>
                                                                </a>
                                                                <div class="sub-menu" data-subwidth="40" >
                                                                    <div class="content">
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <div class="row">
                                                                                    <div class="col-md-12 static-menu">
                                                                                        <div class="menu">
                                                                                            <ul>
                                                                                                <li><a href="#" class="main-menu">Smartphone</a>
                                                                                                    <ul>
                                                                                                        <li><a href="#">Esdipiscing</a>
                                                                                                        </li>
                                                                                                        <li><a href="#">Scanners</a>
                                                                                                        </li>
                                                                                                        <li><a href="#">Apple</a>
                                                                                                        </li>
                                                                                                        <li><a href="#">Dell</a>
                                                                                                        </li>
                                                                                                        <li><a href="#">Scanners</a>
                                                                                                        </li>
                                                                                                    </ul>
                                                                                                </li>
                                                                                                <li><a href="#" class="main-menu">Electronics</a>
                                                                                                    <ul>
                                                                                                        <li><a href="#">Asdipiscing</a>
                                                                                                        </li>
                                                                                                        <li><a href="#">Diam sit</a>
                                                                                                        </li>
                                                                                                        <li><a href="#">Labore et</a>
                                                                                                        </li>
                                                                                                        <li><a href="#">Monitors</a>
                                                                                                        </li>
                                                                                                    </ul>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-md-6">
                                                                                <div class="row banner">
                                                                                    <a href="#">
                                                                                        <img src="{!!asset('front/image/catalog/menu/megabanner/vbanner1.jpg') !!}" alt="banner1">
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                            <li class="item-vertical with-sub-menu hover">
                                                                <p class="close-menu"></p>
                                                                <a href="#" class="clearfix">
                                                                     <img src="{!!asset('front/image/catalog/menu/icons/ico7.png') !!}" alt="icon">
                                                                    <span>Health &amp; Beauty</span>
                                                                    <b class="caret"></b>
                                                                </a>
                                                                <div class="sub-menu" data-subwidth="60" >
                                                                    <div class="content" >
                                                                        <div class="row">
                                                                            <div class="col-md-12">
                                                                                <div class="row">
                                                                                    <div class="col-md-4 static-menu">
                                                                                        <div class="menu">
                                                                                            <ul>
                                                                                                <li>
                                                                                                    <a href="#" class="main-menu">Car Alarms and Security</a>
                                                                                                    <ul>
                                                                                                        <li><a href="#" >Car Audio &amp; Speakers</a></li>
                                                                                                        <li><a href="#" >Gadgets &amp; Auto Parts</a></li>
                                                                                                        <li><a href="#" >Gadgets &amp; Auto Parts</a></li>
                                                                                                        <li><a href="#" >Headphones, Headsets</a></li>
                                                                                                    </ul>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <a href="24.html" onclick="window.location = '24.html';" class="main-menu">Health &amp; Beauty</a>
                                                                                                    <ul>
                                                                                                        <li>
                                                                                                            <a href="#" >Home Audio</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                            <a href="#" >Helicopters &amp; Parts</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                            <a href="#" >Outdoor &amp; Traveling</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                            <a href="#">Toys &amp; Hobbies</a>
                                                                                                        </li>
                                                                                                    </ul>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col-md-4 static-menu">
                                                                                        <div class="menu">
                                                                                            <ul>
                                                                                                <li>
                                                                                                    <a href="#"  class="main-menu">Electronics</a>
                                                                                                    <ul>
                                                                                                        <li>
                                                                                                            <a href="#">Earings</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                            <a href="#" >Salon &amp; Spa Equipment</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                            <a href="#" >Shaving &amp; Hair Removal</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                            <a href="#">Smartphone &amp; Tablets</a>
                                                                                                        </li>
                                                                                                    </ul>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <a href="#"  class="main-menu">Sports &amp; Outdoors</a>
                                                                                                    <ul>
                                                                                                        <li>
                                                                                                            <a href="#" >Flashlights &amp; Lamps</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                            <a href="#" >Fragrances</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                            <a href="#" >Fishing</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                            <a href="#" >FPV System &amp; Parts</a>
                                                                                                        </li>
                                                                                                    </ul>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col-md-4 static-menu">
                                                                                        <div class="menu">
                                                                                            <ul>
                                                                                                <li>
                                                                                                    <a href="#" class="main-menu">More Car Accessories</a>
                                                                                                    <ul>
                                                                                                        <li>
                                                                                                            <a href="#" >Lighter &amp; Cigar Supplies</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                            <a href="#" >Mp3 Players &amp; Accessories</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                            <a href="#" >Men Watches</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                            <a href="#" >Mobile Accessories</a>
                                                                                                        </li>
                                                                                                    </ul>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <a href="#" class="main-menu">Gadgets &amp; Auto Parts</a>
                                                                                                    <ul>
                                                                                                        <li>
                                                                                                            <a href="#" >Gift &amp; Lifestyle Gadgets</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                            <a href="#" >Gift for Man</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                            <a href="#" >Gift for Woman</a>
                                                                                                        </li>
                                                                                                        <li>
                                                                                                            <a href="#" >Gift for Woman</a>
                                                                                                        </li>
                                                                                                    </ul>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="item-vertical css-menu with-sub-menu hover">
                                                                <p class="close-menu"></p>
                                                                <a href="#" class="clearfix">
                                                                    
                                                                     <img src="{!!asset('front/image/catalog/menu/icons/ico6.png') !!}" alt="icon">
                                                                    <span>Smartphone &amp; Tablets</span>
                                                                    <b class="caret"></b>
                                                                </a>
                                                                <div class="sub-menu" data-subwidth="20">
                                                                    <div class="content" >
                                                                        <div class="row">
                                                                            <div class="col-sm-12">
                                                                                <div class="row">
                                                                                    <div class="col-sm-12 hover-menu">
                                                                                        <div class="menu">
                                                                                            <ul>
                                                                                                <li>
                                                                                                    <a href="#" class="main-menu">Headphones, Headsets</a>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <a href="#" class="main-menu">Home Audio</a>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <a href="#" class="main-menu">Health &amp; Beauty</a>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <a href="#" class="main-menu">Helicopters &amp; Parts</a>
                                                                                                </li>
                                                                                                <li>
                                                                                                    <a href="#" class="main-menu">Helicopters &amp; Parts</a>
                                                                                                </li>
                                                                                            </ul>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                            <li class="item-vertical">
                                                                <p class="close-menu"></p>
                                                                <a href="#" class="clearfix">
                                                                     <img src="{!!asset('front/image/catalog/menu/icons/ico5.png') !!}" alt="icon">
                                                                    <span>Health & Beauty</span>
                                                                    
                                                                </a>
                                                            </li>
                                                            <li class="item-vertical">
                                                                <p class="close-menu"></p>
                                                                <a href="#" class="clearfix">
                                                                     <img src="{!!asset('front/image/catalog/menu/icons/ico4.png') !!}" alt="icon">
                                                                    <span>Bathroom</span>
                                                                </a>
                                                            </li>
                                                            <li class="item-vertical">
                                                                <p class="close-menu"></p>
                                                                <a href="#" class="clearfix">
                                                                     <img src="{!!asset('front/image/catalog/menu/icons/ico3.png') !!}" alt="icon">
                                                                    <span>Metallurgy</span>
                                                                </a>
                                                            </li>
                                                            <li class="item-vertical" >
                                                                <p class="close-menu"></p>
                                                                <a href="#" class="clearfix">
                                                                    <img src="{!!asset('front/image/catalog/menu/icons/ico2.png') !!}" alt="icon">
                                                                    <span>Bedroom</span>
                                                                </a>
                                                            </li>
                                                            <li class="item-vertical" >
                                                                <p class="close-menu"></p>
                                                                
                                                                <a href="#" class="clearfix">
                                                                     <img src="{!!asset('front/image/catalog/menu/icons/ico1.png') !!}" alt="icon">
                                                                    <span>Health &amp; Beauty</span>
                                                                </a>
                                                            </li>
                                                            <li class="item-vertical" style="display: none;">
                                                                <p class="close-menu"></p>
                                                                <a href="#" class="clearfix">
                                                                     <img src="{!!asset('front/image/catalog/menu/icons/ico11.png') !!}" alt="icon">
                                                                    <span>Toys &amp; Hobbies </span>
                                                                </a>
                                                            </li>
                                                            <li class="item-vertical" style="display: none;">
                                                                <p class="close-menu"></p>
                                                                <a href="#" class="clearfix">
                                                                     <img src="{!!asset('front/image/catalog/menu/icons/ico12.png') !!}" alt="icon">
                                                                    <span>Jewelry &amp; Watches</span>
                                                                </a>
                                                            </li>
                                                            <li class="item-vertical" style="display: none;">
                                                                <p class="close-menu"></p>
                                                                <a href="#" class="clearfix">
                                                                     <img src="{!!asset('front/image/catalog/menu/icons/ico9.png') !!}" alt="icon">
                                                                    <span>Home &amp; Lights</span>
                                                                </a>
                                                            </li>
                                                            <li class="item-vertical" style="display: none;">
                                                                <p class="close-menu"></p>
                                                                <a href="#" class="clearfix">
                                                                     <img src="{!!asset('front/image/catalog/menu/icons/ico6.png') !!}" alt="icon">
                                                                    <span>Metallurgy</span>
                                                                </a>
                                                            </li>
                                                           
                                                            <li class="loadmore">
                                                                <i class="fa fa-plus-square-o"></i>
                                                                <span class="more-view">More Categories</span>
                                                            </li>
                                                            
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </nav>
                            </div>
                        </div>

                    </div>
                    
                    <!-- Search -->
                    <div class="bottom2 col-lg-7 col-md-6 col-sm-6">
                        <div class="search-header-w">
                            <div class="icon-search hidden-lg hidden-md hidden-sm"><i class="fa fa-search"></i></div>                                
                              
                            <div id="sosearchpro" class="sosearchpro-wrapper so-search ">
                                <form method="GET" action="http://demo.smartaddons.com/templates/html/emarket/index.php">
                                    <div id="search0" class="search input-group form-group">
                                        <div class="select_category filter_type  icon-select hidden-sm hidden-xs">
                                            <select class="no-border" name="category_id">
                                                <option value="0">All Categories</option>
                                                <option value="78">Apparel</option>
                                                <option value="77">Cables &amp; Connectors</option>
                                                <option value="82">Cameras &amp; Photo</option>
                                                <option value="80">Flashlights &amp; Lamps</option>
                                                <option value="81">Mobile Accessories</option>
                                                <option value="79">Video Games</option>
                                                <option value="20">Jewelry &amp; Watches</option>
                                                <option value="76">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Earings</option>
                                                <option value="26">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wedding Rings</option>
                                                <option value="27">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Men Watches</option>
                                            </select>
                                        </div>

                                        <input class="autosearch-input form-control" type="text" value="" size="50" autocomplete="off" placeholder="Keyword here..." name="search">
                                        <span class="input-group-btn">
                                        <button type="submit" class="button-search btn btn-primary" name="submit_search"><i class="fa fa-search"></i></button>
                                        </span>
                                    </div>
                                    <input type="hidden" name="route" value="product/search" />
                                </form>
                            </div>
                        </div>  
                    </div>
                    <!-- //end Search -->
                    
                    <!-- Secondary menu -->
                    <div class="bottom3 col-lg-3 col-md-3 col-sm-3">
                        

                        <!--cart-->
                        <div class="shopping_cart">
                            <div id="cart" class="btn-shopping-cart">

                                <a data-loading-text="Loading... " class="btn-group top_cart dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                    <div class="shopcart">
                                        <span class="icon-c">
                                <i class="fa fa-shopping-bag"></i>
                              </span>
                                        <div class="shopcart-inner">
                                            <p class="text-shopping-cart">

                                                My cart
                                            </p>

                                            <span class="total-shopping-cart cart-total-full">
                                   <span class="items_cart">02</span><span class="items_cart2"> item(s)</span><span class="items_carts"> - $162.00 </span>
                                            </span>
                                        </div>
                                    </div>
                                </a>

                                <ul class="dropdown-menu pull-right shoppingcart-box" role="menu">
                                    <li>
                                        <table class="table table-striped">
                                            <tbody>
                                                <tr>
                                                    <td class="text-center" style="width:70px">
                                                        <a href="product.html">
                                                            <img src="{!!asset('front/image/catalog/demo/product/80/1.jpg') !!}" style="width:70px" alt="Yutculpa ullamcon" title="Yutculpa ullamco" class="preview">
                                                        </a>
                                                    </td>
                                                    <td class="text-left"> <a class="cart_product_name" href="product.html">Yutculpa ullamco</a> 
                                                    </td>
                                                    <td class="text-center">x1</td>
                                                    <td class="text-center">$80.00</td>
                                                    <td class="text-right">
                                                        <a href="product.html" class="fa fa-edit"></a>
                                                    </td>
                                                    <td class="text-right">
                                                        <a onclick="cart.remove('2');" class="fa fa-times fa-delete"></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="text-center" style="width:70px">
                                                        <a href="product.html">
                                                            <img src="{!!asset('front/image/catalog/demo/product/80/2.jpg') !!}" style="width:70px" alt="Xancetta bresao" title="Xancetta bresao" class="preview">
                                                        </a>
                                                    </td>
                                                    <td class="text-left"> <a class="cart_product_name" href="product.html">Xancetta bresao</a> 
                                                    </td>
                                                    <td class="text-center">x1</td>
                                                    <td class="text-center">$60.00</td>
                                                    <td class="text-right">
                                                        <a href="product.html" class="fa fa-edit"></a>
                                                    </td>
                                                    <td class="text-right">
                                                        <a onclick="cart.remove('1');" class="fa fa-times fa-delete"></a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </li>
                                    <li>
                                        <div>
                                            <table class="table table-bordered">
                                                <tbody>
                                                    <tr>
                                                        <td class="text-left"><strong>Sub-Total</strong>
                                                        </td>
                                                        <td class="text-right">$140.00</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-left"><strong>Eco Tax (-2.00)</strong>
                                                        </td>
                                                        <td class="text-right">$2.00</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-left"><strong>VAT (20%)</strong>
                                                        </td>
                                                        <td class="text-right">$20.00</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-left"><strong>Total</strong>
                                                        </td>
                                                        <td class="text-right">$162.00</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <p class="text-right"> <a class="btn view-cart" href="cart.html"><i class="fa fa-shopping-cart"></i>View Cart</a>&nbsp;&nbsp;&nbsp; <a class="btn btn-mega checkout-cart" href="checkout.html"><i class="fa fa-share"></i>Checkout</a> 
                                            </p>
                                        </div>
                                    </li>
                                </ul>
                            </div>

                        </div>
                        <!--//cart-->

                        <ul class="wishlist-comp hidden-md hidden-sm hidden-xs">
                            <li class="compare hidden-xs"><a href="#" class="top-link-compare" title="Compare "><i class="fa fa-refresh"></i></a>
                            </li>
                            <li class="wishlist hidden-xs"><a href="#" id="wishlist-total" class="top-link-wishlist" title="Wish List (0) "><i class="fa fa-heart"></i></a>
                            </li>
                        </ul>
                    </div>
                    
                </div>
            </div>

        </div>
    </header>
    <!-- //Header Container  -->
    
   
<!-- Main Container  -->
<div class="main-container container">
    <div id="content">
        <div class="box-top hidden-lg hidden-md hidden-sm ">
            <div class="module sohomepage-slider ">
                <div class="yt-content-slider"  data-rtl="yes" data-autoplay="no" data-autoheight="no" data-delay="4" data-speed="0.6" data-margin="0" data-items_column0="1" data-items_column1="1" data-items_column2="1"  data-items_column3="1" data-items_column4="1" data-arrows="no" data-pagination="yes" data-lazyload="yes" data-loop="no" data-hoverpause="yes">
                    <div class="yt-content-slide">
                        <a href="#"><img src="{!!asset('front/image/catalog/slideshow/home1/slider-1.jpg') !!}" alt="slider1" class="img-responsive"></a>
                    </div>
                    <div class="yt-content-slide">
                        <a href="#"><img src="{!!asset('front/image/catalog/slideshow/home1/slider-2.jpg') !!}" alt="slider2" class="img-responsive"></a>
                    </div>
                    <div class="yt-content-slide">
                        <a href="#"><img src="{!!asset('front/image/catalog/slideshow/home1/slider-3.jpg') !!}" alt="slider3" class="img-responsive"></a>
                    </div>
                </div>
                
                <div class="loadeding"></div>
            </div>                                             
        </div>
        <div class="row">
            <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12 main-left sidebar-offcanvas">
                <div class="module col1 hidden-sm hidden-xs"></div>
                <div class="module">
                    <div class="banners banners2">
                        <div class="banner">
                            <a href="#"><img src="{!!asset('front/image/catalog/banners/banner4.jpg') !!}" alt="image"></a>
                        </div>
                    </div>
                </div>
                <div class="module product-simple">
                    <h3 class="modtitle">
                        <span>Latest products</span>
                    </h3>
                    <div class="modcontent">
                        <div id="so_extra_slider_1" class="extraslider" >
                            <!-- Begin extraslider-inner -->
                            <div class="yt-content-slider extraslider-inner" data-rtl="yes" data-pagination="yes" data-autoplay="no" data-delay="4" data-speed="0.6" data-margin="0" data-items_column0="1" data-items_column1="1" data-items_column2="1" data-items_column3="1" data-items_column4="1" data-arrows="no" data-lazyload="yes" data-loop="no" data-buttonpage="top">
                                <div class="item ">
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Mandouille short ">
                                                    <img src="{!!asset('front/image/catalog/demo/product/80/1.jpg') !!}" alt="Mandouille short">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Mandouille short">Mandouille short </a>
                                            </div>
                                            <div class="rating">
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price-new product-price">$55.00 </span>&nbsp;&nbsp;
                                                <span class="price-old">$76.00 </span>&nbsp;
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Xancetta bresao ">
                                                    <img src="{!!asset('front/image/catalog/demo/product/80/2.jpg') !!}" alt="Xancetta bresao">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Xancetta bresao">
                                                    Xancetta bresao 
                                                </a>
                                            </div>
                                            <div class="rating">
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price-new product-price">$80.00 </span>&nbsp;&nbsp;
                                                <span class="price-old">$89.00 </span>&nbsp;
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Sausage cowbee ">
                                                    <img src="{!!asset('front/image/catalog/demo/product/80/3.jpg') !!}" alt="Sausage cowbee">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Sausage cowbee">
                                                    Sausage cowbee 
                                                </a>
                                            </div>
                                            <div class="rating">
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price product-price">
                                                    $66.00 
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Chicken swinesha ">
                                                    <img src="{!!asset('front/image/catalog/demo/product/80/4.jpg') !!}" alt="Chicken swinesha">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Chicken swinesha">
                                                    Chicken swinesha 
                                                </a>
                                            </div>
                                            <div class="rating">
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price-new product-price">$45.00 </span>&nbsp;&nbsp;
                                                <span class="price-old">$56.00 </span>&nbsp;
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item ">
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Qeserunt shortloin ">
                                                <img src="{!!asset('front/image/catalog/demo/product/80/5.jpg') !!}" alt="Qeserunt shortloin">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Qeserunt shortloin">Qeserunt shortloin  </a>
                                            </div>
                                            <div class="rating">
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price product-price"> $88.00 </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Consecte quichuck ">
                                                <img src="{!!asset('front/image/catalog/demo/product/80/6.jpg') !!}" alt="Consecte quichuck">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Consecte quichuck"> Consecte quichuck </a>
                                            </div>
                                            <div class="rating">
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price-new product-price">$55.00 </span>&nbsp;&nbsp;
                                                <span class="price-old">$61.00 </span>&nbsp;
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Neatball bresaola ">
                                                    <img src="{!!asset('front/image/catalog/demo/product/80/7.jpg') !!}" alt="Neatball bresaola">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Neatball bresaola"> Neatball bresaola  </a>
                                            </div>
                                            <div class="rating">
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price-new product-price">$65.00 </span>&nbsp;&nbsp;
                                                <span class="price-old">$71.00 </span>&nbsp;
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Yutculpa ullamco ">
                                                <img src="{!!asset('front/image/catalog/demo/product/80/8.jpg') !!}" alt="Yutculpa ullamco">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Yutculpa ullamco">
                                                    Yutculpa ullamco 
                                                </a>
                                            </div>
                                            <div class="rating">
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price-new product-price">$60.00 </span>&nbsp;&nbsp;
                                                <span class="price-old">$77.00 </span>&nbsp;
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="module">
                    <ul class="block-infos">
                        <li class="info1">
                            <div class="inner">
                                <i class="fa fa-file-text-o"></i>
                                <div class="info-cont">
                                    <a href="#">free delivery</a>
                                    <p>On order over $49.86</p>
                                </div>
                            </div>
                        </li>
                        <li class="info2">
                            <div class="inner">
                                <i class="fa fa-shield"></i>
                                <div class="info-cont">
                                    <a href="#">order protecttion</a>
                                    <p>secured information</p>
                                </div>
                            </div>
                        </li>
                        <li class="info3">
                            <div class="inner">
                                <i class="fa fa-gift"></i>
                                <div class="info-cont">
                                    <a href="#">promotion gift</a>
                                    <p>special offers!</p>
                                </div>
                            </div>
                        </li>
                        <li class="info4">
                            <div class="inner">
                                <i class="fa fa-money"></i>
                                <div class="info-cont">
                                    <a href="#">money back</a>
                                    <p>return over 30 days</p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="module">
                    <div class="banners banners4">
                        <div class="banner">
                            <a href="#"><img src="{!!asset('front/image/catalog/banners/banner5.jpg') !!}" alt="image"></a>
                        </div>
                    </div>
                </div>

                <!-- <div class="module blog-sidebar">
                    <h3 class="modtitle"><span>Latest Blogs</span></h3>
                    <div class="modcontent clearfix">
                        <div id="so_latest_blog_103_1728994661514993652" class="so-blog-external buttom-type1 button-type1">
                            <div class="yt-content-slider blog-external" data-autoplay="no" data-autoheight="no" data-delay="4" data-speed="0.6" data-margin="0" data-items_column0="1" data-items_column1="1" data-items_column2="1" data-items_column3="1" data-items_column4="1" data-arrows="no"
                            data-pagination="yes" data-lazyload="yes" data-loop="yes" data-buttonpage="top">
                                <div class="media" > 
                                    <div class="item head-button">
                                        <div class="media-left so-block">
                                            <a href="#" target="_self">
                                                <img src="image/catalog/blog/2.jpg" alt="Duis autem vel eum irure sed diam nonumy">
                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <div class="media-content so-block">
                                                <h4 class="media-heading font-title head-item">
                                                    <a href="#" title="Duis autem vel eum irure sed diam nonumy" target="_self">Duis autem vel eum irure sed diam nonumy</a>
                                                </h4>
                                                <div class="media-date-added">
                                                    <i class="fa fa-calendar"></i><span class="media-date-added"> December 4th, 2017</span>
                                                </div>
                                                <div class="media-subcontent">
                                                    <span class="media-comment"><i class="fa fa-comments"></i> 0  Comment</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="media" > 
                                    <div class="item head-button">
                                        <div class="media-left so-block">
                                            <a href="#" target="_self">
                                                <img src="image/catalog/blog/4.jpg" alt="Duis autem vel eum irure sed diam nonumy">
                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <div class="media-content so-block">
                                                <h4 class="media-heading font-title head-item">
                                                    <a href="#" title="Biten demons lector in henderit in vulp" target="_self">Biten demons lector in henderit in vulp</a>
                                                </h4>
                                                <div class="media-date-added">
                                                    <i class="fa fa-calendar"></i><span class="media-date-added"> December 4th, 2017</span>
                                                </div>
                                                <div class="media-subcontent">
                                                    <span class="media-comment"><i class="fa fa-comments"></i> 0  Comment</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="media" > 
                                    <div class="item head-button">
                                        <div class="media-left so-block">
                                            <a href="#" target="_self">
                                                <img src="image/catalog/blog/1.jpg" alt="Duis autem vel eum irure sed diam nonumy">
                                            </a>
                                        </div>
                                        <div class="media-body">
                                            <div class="media-content so-block">
                                                <h4 class="media-heading font-title head-item">
                                                    <a href="#" title="Commodo laoreet semper tincidun  sit" target="_self">Commodo laoreet semper tincidun  sit</a>
                                                </h4>
                                                <div class="media-date-added">
                                                    <i class="fa fa-calendar"></i><span class="media-date-added"> December 4th, 2017</span>
                                                </div>
                                                <div class="media-subcontent">
                                                    <span class="media-comment"><i class="fa fa-comments"></i> 0  Comment</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>    
                            </div>
                        </div>
                    </div>
                </div> -->
                <div class="module product-simple">
                    <h3 class="modtitle">
                        <span>Top Rated</span>
                    </h3>
                    <div class="modcontent">
                        <div id="so_extra_slider_2" class="extraslider" >
                            <!-- Begin extraslider-inner -->
                            <div class="yt-content-slider extraslider-inner" data-rtl="yes" data-pagination="yes" data-autoplay="no" data-delay="4" data-speed="0.6" data-margin="0" data-items_column0="1" data-items_column1="1" data-items_column2="1" data-items_column3="1" data-items_column4="1" data-arrows="no"
                            data-lazyload="yes" data-loop="no" data-buttonpage="top">
                                <div class="item ">
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Mandouille short ">
                                                    <img src="{!!asset('front/image/catalog/demo/product/80/8.jpg') !!}" alt="Mandouille short">
                                                    </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Mandouille short">Mandouille short </a>
                                            </div>
                                            <div class="rating">
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price-new product-price">$55.00 </span>&nbsp;&nbsp;
                                                <span class="price-old">$76.00 </span>&nbsp;
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End item-wrap -->
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Xancetta bresao ">
                                                    <img src="{!!asset('front/image/catalog/demo/product/80/7.jpg') !!}" alt="Xancetta bresao">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Xancetta bresao">
                                                   Xancetta bresao 
                                                </a>
                                            </div>
                                            <div class="rating">
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price-new product-price">$80.00 </span>&nbsp;&nbsp;
                                                <span class="price-old">$89.00 </span>&nbsp;
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End item-wrap -->
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Sausage cowbee ">
                                                    <img src="{!!asset('front/image/catalog/demo/product/80/6.jpg') !!}" alt="Sausage cowbee">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Sausage cowbee">
                                                    Sausage cowbee 
                                                </a>
                                            </div>
                                            <div class="rating">
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price product-price">
                                                    $66.00 
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Chicken swinesha ">
                                                <img src="{!!asset('front/image/catalog/demo/product/80/5.jpg') !!}" alt="Chicken swinesha">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Chicken swinesha">
                                                   Chicken swinesha 
                                                </a>
                                            </div>
                                             <div class="rating">
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price-new product-price">$45.00 </span>&nbsp;&nbsp;
                                                <span class="price-old">$56.00 </span>&nbsp;
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item ">
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Qeserunt shortloin ">
                                                <img src="{!!asset('front/image/catalog/demo/product/80/4.jpg') !!}" alt="Qeserunt shortloin">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Qeserunt shortloin">
                                                    Qeserunt shortloin 
                                                </a>
                                            </div>
                                            <div class="rating">
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price product-price">
                                                    $88.00 
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Consecte quichuck ">
                                                <img src="{!!asset('front/image/catalog/demo/product/80/3.jpg') !!}" alt="Consecte quichuck">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Consecte quichuck">
                                                    Consecte quichuck 
                                                </a>
                                            </div>
                                            <div class="rating">
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price-new product-price">$55.00 </span>&nbsp;&nbsp;
                                                <span class="price-old">$61.00 </span>&nbsp;
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Neatball bresaola ">
                                                    <img src="{!!asset('front/image/catalog/demo/product/80/2.jpg') !!}" alt="Neatball bresaola">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Neatball bresaola">
                                                    Neatball bresaola 
                                                </a>
                                            </div>
                                            <div class="rating">
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price-new product-price">$65.00 </span>&nbsp;&nbsp;
                                                <span class="price-old">$71.00 </span>&nbsp;
                                            </div>
                                        </div>
                                    </div>
                                    <div class="product-layout item-inner style1 ">
                                        <div class="item-image">
                                            <div class="item-img-info">
                                                <a href="#" target="_self" title="Yutculpa ullamco ">
                                                <img src="{!!asset('front/image/catalog/demo/product/80/1.jpg') !!}" alt="Yutculpa ullamco">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="item-info">
                                            <div class="item-title">
                                                <a href="#" target="_self" title="Yutculpa ullamco">
                                                    Yutculpa ullamco 
                                                </a>
                                            </div>
                                            <div class="rating">
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                                <span class="fa fa-stack">
                                                    <i class="fa fa-star fa-stack-2x"></i>
                                                </span>
                                            </div>
                                            <div class="content_price price">
                                                <span class="price-new product-price">$60.00 </span>&nbsp;&nbsp;
                                                <span class="price-old">$77.00 </span>&nbsp;
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                 <div class="module">
                    <div class="banners banners2">
                        <div class="banner">
                            <a href="#"><img src="{!!asset('front/image/catalog/banners/banner4.jpg') !!}" alt="image"></a>
                        </div>
                    </div>
                </div>
                <!-- <div class="module">
                    <div class="banners banners5">
                        <div class="banner">
                            <a href="#"><img src="image/catalog/banners/banner6.jpg" alt="image"></a>
                        </div>
                    </div>
                </div> -->
            </div>
            <div class="col-lg-10 col-md-9 col-sm-8 col-xs-12 main-right">
                <div class="slider-container row">      
                    <div class="col-lg-9 col-md-8 col-sm-8 col-xs-12 col2">
                        <div class="module sohomepage-slider ">
                            <div class="yt-content-slider"  data-rtl="yes" data-autoplay="no" data-autoheight="no" data-delay="4" data-speed="0.6" data-margin="0" data-items_column0="1" data-items_column1="1" data-items_column2="1"  data-items_column3="1" data-items_column4="1" data-arrows="no" data-pagination="yes" data-lazyload="yes" data-loop="no" data-hoverpause="yes">
                                <div class="yt-content-slide">
                                    <a href="#"><img src="{!!asset('front/image/catalog/slideshow/home1/slider-1.jpg') !!}" alt="slider1" class="img-responsive"></a>
                                </div>
                                <div class="yt-content-slide">
                                    <a href="#"><img src="{!!asset('front/image/catalog/slideshow/home1/slider-2.jpg') !!}" alt="slider2" class="img-responsive"></a>
                                </div>
                                <div class="yt-content-slide">
                                    <a href="#"><img src="{!!asset('front/image/catalog/slideshow/home1/slider-3.jpg') !!}" alt="slider3" class="img-responsive"></a>
                                </div>
                            </div>
                            <div class="loadeding"></div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12 col3">
                        <div class="modcontent clearfix">
                            <div class="banners banners1"> 
                                <div class="b-img">
                                    <a href="#"><img src="{!!asset('front/image/catalog/banners/banner1.jpg') !!}" alt="banner1"></a>
                                </div>
                                <div class="b-img2">
                                    <a href="#"><img src="{!!asset('front/image/catalog/banners/banner2.jpg') !!}" alt="banner2"></a>
                                </div>    
                            </div>
                        </div>
                    </div>                
                </div>
                <div class="banners banners3">
                    <div class="banner">
                        <a href="#">
                            <img src="{!!asset('front/image/catalog/banners/banner3.jpg') !!}" alt="image">
                        </a>
                    </div>
                </div>
                <!-- Deals -->
                <div class="module deals-layout1">
                    <h3 class="modtitle"><span>Daily Deals</span></h3>
                    <div class="modcontent">
                        <div id="so_deal_1" class="so-deal style2">
                            <div class="extraslider-inner products-list yt-content-slider" data-rtl="yes" data-autoplay="no" data-autoheight="no" data-delay="4" data-speed="0.6" data-margin="30" data-items_column0="2" data-items_column1="1" data-items_column2="1"  data-items_column3="1" data-items_column4="1" data-arrows="yes" data-pagination="yes" data-lazyload="yes" data-loop="no" data-hoverpause="yes">
                                <div class="item">
                                    <div class="product-thumb">
                                        <div class="row">
                                            <div class="inner">
                                                <div class="item-left col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                    <div class="image"> 
                                                        <span class="label-product label-product-sale">
                                                            -22%
                                                        </span>
                                                        <a href="#" target="_self" title="product">
                                                            <img src="{!!asset('front/image/catalog/demo/product/320/1.jpg') !!}" alt="Yutculpa ullamco" class="img-responsive">
                                                        </a>
                                                        <div class="button-group so-quickview">
                                                            <button class="btn-button addToCart" title="Add to Cart" type="button" onclick="cart.add('69');"><i class="fa fa-shopping-basket"></i>  <span>Add to Cart</span>
                                                            </button>                                                        
                                                            <button class="btn-button wishlist" type="button" title="Add to Wish List" onclick="wishlist.add('69');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                            </button>
                                                            <button class="btn-button compare" type="button" title="Compare this Product" onclick="compare.add('69');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                            </button>                                                    
                                                            <!--quickview-->                                                      
                                                            <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                            <!--end quickview-->
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-right col-lg-6 col-md-7 col-sm-7 col-xs-12">
                                                    <div class="caption">
                                                        <h4><a href="#" target="_self" title="Yutculpa ullamco">Yutculpa ullamco</a></h4>
                                                        <p class="price">   <span class="price-new">$60.00</span>
                                                            <span class="price-old">$77.00</span>
                                                        </p>
                                                        <p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore..</p>
                                                        <div class="item-available">
                                                            <div class="row">
                                                                <p class="col-xs-6 a1">Available: <b>98</b> 
                                                                </p>
                                                                <p class="col-xs-6 a2">Sold: <b>32</b> 
                                                                </p>
                                                            </div>
                                                            <div class="available"> <span class="color_width" data-title="75%" data-toggle="tooltip" title="75%" style="width: 75%"></span>
                                                            </div>
                                                        </div>
                                                        <!--countdown box-->
                                                        <div class="item-time-w">
                                                            <div class="time-title"><span>Hurry Up!</span> Offer ends in:</div>
                                                                <div class="item-time">
                                                                    <div class="item-timer">
                                                                        <div class="defaultCountdown-30"></div>
                                                                    </div>
                                                                </div>                                   
                                                        </div>                                                    
                                                        <!--end countdown box-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="product-thumb ">
                                        <div class="row">
                                            <div class="inner">
                                                <div class="item-left col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                    <div class="image"> 
                                                        <span class="label-product label-product-sale">
                                                            -10%
                                                        </span>
                                                        <a href="#" target="_self" title="Xancetta bresao">
                                                            <img src="{!!asset('front/image/catalog/demo/product/320/2.jpg') !!}" alt="Xancetta bresao" class="img-responsive">
                                                        </a>
                                                        <div class="button-group so-quickview">
                                                            <button class="btn-button addToCart" title="Add to Cart" type="button" onclick="cart.add('75');"><i class="fa fa-shopping-basket"></i>  <span>Add to Cart</span>
                                                            </button>
                                                            <button class="btn-button wishlist" type="button" title="Add to Wish List" onclick="wishlist.add('75');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                            </button>
                                                            <button class="btn-button compare" type="button" title="Compare this Product" onclick="compare.add('75');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                            </button>
                                                            <!--quickview-->                                                      
                                                            <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                            <!--end quickview-->
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-right col-lg-6 col-md-7 col-sm-7 col-xs-12">
                                                    <div class="caption">
                                                        <h4><a href="#" target="_self" title="Xancetta bresao">Xancetta bresao</a></h4>
                                                        <p class="price">   <span class="price-new">$80.00</span>
                                                            <span class="price-old">$89.00</span>
                                                        </p>
                                                        <p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore..</p>
                                                        <div class="item-available">
                                                            <div class="row">
                                                                <p class="col-xs-6 a1">Available: <b>555</b> 
                                                                </p>
                                                                <p class="col-xs-6 a2">Sold: <b>0</b> 
                                                                </p>
                                                            </div>
                                                            <div class="available"> <span class="color_width" data-title="0%" data-toggle="tooltip" title="75%" style="width: 0%"></span>
                                                            </div>
                                                        </div>
                                                        <!--countdown box-->
                                                        <div class="item-time-w">
                                                            <div class="time-title"><span>Hurry Up!</span> Offer ends in:</div>
                                                            <div class="item-time">
                                                                <div class="item-timer">
                                                                    <div class="defaultCountdown-30"></div>
                                                                </div>
                                                            </div>                                 
                                                        </div>                                                    
                                                        <!--end countdown box-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="product-thumb transition ">
                                        <div class="row">
                                            <div class="inner">
                                                <div class="item-left col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                    <div class="image">
                                                        <span class="label-product label-product-sale">-17%</span>
                                                        <a href="#" target="_self" title="Wamboudin ribeye">
                                                            <img src="{!!asset('front/image/catalog/demo/product/320/3.jpg') !!}" alt="Wamboudin ribeye" class="img-responsive">
                                                        </a>
                                                        <div class="button-group so-quickview">
                                                            <button class="btn-button addToCart" title="Add to Cart" type="button" onclick="cart.add('79');"><i class="fa fa-shopping-basket"></i>  <span>Add to Cart</span>
                                                            </button>
                                                            <button class="btn-button wishlist" type="button" title="Add to Wish List" onclick="wishlist.add('79');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                            </button>
                                                            <button class="btn-button compare" type="button" title="Compare this Product" onclick="compare.add('79');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                            </button>
                                                            <!--quickview-->                                                      
                                                            <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                            <!--end quickview-->
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-right col-lg-6 col-md-7 col-sm-7 col-xs-12">
                                                    <div class="caption">
                                                        <h4><a href="#" target="_self" title="Wamboudin ribeye">Wamboudin ribeye</a></h4>
                                                        <p class="price">   <span class="price-new">$70.00</span>
                                                            <span class="price-old">$84.00</span>
                                                        </p>
                                                        <p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore..</p>
                                                        <div class="item-available">
                                                            <div class="row">
                                                                <p class="col-xs-6 a1">Available: <b>100</b> 
                                                                </p>
                                                                <p class="col-xs-6 a2">Sold: <b>60</b> 
                                                                </p>
                                                            </div>
                                                            <div class="available"> <span class="color_width" data-title="63%" data-toggle="tooltip" title="63%" style="width: 63%"></span>
                                                            </div>
                                                        </div>
                                                        <!--countdown box-->
                                                        <div class="item-time-w">
                                                            <div class="time-title"><span>Hurry Up!</span> Offer ends in:</div>
                                                            <div class="item-time">
                                                                <div class="item-timer">
                                                                    <div class="defaultCountdown-30"></div>
                                                                </div>
                                                            </div>
                                                                                                                                                                
                                                        </div>                                                    
                                                        <!--end countdown box-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="product-thumb transition ">
                                        <div class="row">
                                            <div class="inner">
                                                <div class="item-left col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                    <div class="image">
                                                        <span class="label-product label-product-sale">-16%</span>
                                                        <a href="#" target="_self" title="Proident leerkas">
                                                            <img src="{!!asset('front/image/catalog/demo/product/320/4.jpg') !!}" alt="Proident leerkas" class="img-responsive">
                                                        </a>
                                                        <div class="button-group so-quickview">
                                                            <button class="btn-button addToCart" title="Add to Cart" type="button" onclick="cart.add('55');"><i class="fa fa-shopping-basket"></i>  <span>Add to Cart</span>
                                                            </button>
                                                            <button class="btn-button wishlist" type="button" title="Add to Wish List" onclick="wishlist.add('55');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                            </button>
                                                            <button class="btn-button compare" type="button" title="Compare this Product" onclick="compare.add('55');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                            </button>
                                                            <!--quickview-->                                                      
                                                            <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                            <!--end quickview-->
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-right col-lg-6 col-md-7 col-sm-7 col-xs-12">
                                                    <div class="caption">
                                                        <h4><a href="#" target="_self" title="Wamboudin ribeye">Proident leerkas</a></h4>
                                                        <p class="price">   <span class="price-new">$46.00</span>
                                                            <span class="price-old">$55.00</span>
                                                        </p>
                                                        <p class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore..</p>
                                                        <div class="item-available">
                                                            <div class="row">
                                                                <p class="col-xs-6 a1">Available: <b>310</b> 
                                                                </p>
                                                                <p class="col-xs-6 a2">Sold: <b>2</b> 
                                                                </p>
                                                            </div>
                                                            <div class="available"> <span class="color_width" data-title="99%" data-toggle="tooltip" title="99%" style="width: 99%"></span>
                                                            </div>
                                                        </div>
                                                        <!--countdown box-->
                                                        <div class="item-time-w">
                                                            <div class="time-title"><span>Hurry Up!</span> Offer ends in:</div>
                                                            <div class="item-time">
                                                                <div class="item-timer">
                                                                    <div class="defaultCountdown-30"></div>
                                                                </div>
                                                            </div>
                                                                                                                                                                
                                                        </div>                                                    
                                                        <!--end countdown box-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Deals -->
                <div class="banners banners6">
                    <div class="banner">
                        <a href="#">
                            <img src="{!!asset('front/image/catalog/banners/banner7.jpg') !!}" alt="image">
                        </a>
                    </div>
                </div>
                <!-- Listing tabs -->
                <div class="module listingtab-layout1">
                    <h3 class="modtitle"><span>Trending items</span></h3>
                        <div id="so_listing_tabs_1" class="so-listing-tabs first-load">
                            <div class="loadeding"></div>
                            <div class="ltabs-wrap">
                                <div class="ltabs-tabs-container" data-delay="300" data-duration="600" data-effect="starwars" data-ajaxurl="" data-type_source="0" data-lg="5" data-md="3" data-sm="2" data-xs="1" data-margin="30">
                                    <div class="ltabs-tabs-wrap"> 
                                        <span class="ltabs-tab-selected">Bathroom</span> <span class="ltabs-tab-arrow">▼</span>
                                        <div class="item-sub-cat">
                                            <ul class="ltabs-tabs cf">
                                                <li class="ltabs-tab tab-sel" data-category-id="20" data-active-content=".items-category-20"> <span class="ltabs-tab-label">Bedroom</span> </li>
                                                <li class="ltabs-tab " data-category-id="18" data-active-content=".items-category-18"> <span class="ltabs-tab-label">Decor</span> </li>
                                                <li class="ltabs-tab " data-category-id="25" data-active-content=".items-category-25"> <span class="ltabs-tab-label">Furniture</span> </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="ltabs-items-container products-list grid">
                                    <!--Begin Items-->
                                    <div class="ltabs-items ltabs-items-selected items-category-20" data-total="16">
                                        <div class="ltabs-items-inner ltabs-slider">
                                            <!-- item listing tab -->
                                            <div class="ltabs-item">
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Pastrami bacon">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/1.jpg') !!}" class="img-1 img-responsive" alt="Pastrami bacon">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/12.jpg') !!}" class="img-2 img-responsive" alt="Pastrami bacon">
                                                                </a>
                                                            </div>
                                                            
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="rating">    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
                                                                </div>
                                                                <h4><a href="product.html" title="Pastrami bacon" target="_self">Pastrami bacon</a></h4>
                                                                <div class="price">$42.00</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Chicken swinesha">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/2.jpg') !!}" class="img-1 img-responsive" alt="image">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/11.jpg') !!}" class="img-2 img-responsive" alt="image">
                                                                </a>
                                                            </div>
                                                            <div class="box-label"> <span class="label-product label-sale"> -16% </span></div>
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="rating">    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                </div>
                                                                <h4><a href="product.html" title="Chicken swinesha" target="_self">Chicken swinesha</a></h4>
                                                                <div class="price"> <span class="price-new">$46.00</span>
                                                                    <span class="price-old">$55.00</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- end item listing tab -->
                                            <div class="ltabs-item">
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Kielbasa hamburg">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/3.jpg') !!}" class="img-1 img-responsive" alt="Pastrami bacon">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/10.jpg') !!}" class="img-2 img-responsive" alt="Pastrami bacon">
                                                                </a>
                                                            </div>
                                                            <div class="box-label"> <span class="label-product label-new"> New </span></div>
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="rating">    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
                                                                </div>
                                                                <h4><a href="product.html" title="Kielbasa hamburg" target="_self">Kielbasa hamburg</a></h4>
                                                                <div class="price">$55.00</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Sausage cowbee">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/4.jpg') !!}" class="img-1 img-responsive" alt="image">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/9.jpg') !!}" class="img-2 img-responsive" alt="image">
                                                                </a>
                                                            </div>
                                                            
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="rating">    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                </div>
                                                                <h4><a href="product.html" title="Sausage cowbeea" target="_self">Sausage cowbee</a></h4>
                                                                <div class="price">$60.00</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ltabs-item">
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Kielbasa hamburg">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/5.jpg') !!}" class="img-1 img-responsive" alt="Pastrami bacon">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/8.jpg') !!}" class="img-2 img-responsive" alt="Pastrami bacon">
                                                                </a>
                                                            </div>
                                                            
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="rating">    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-2x"></i></span>
                                                                </div>
                                                                <h4><a href="product.html" title="Drumstick tempor" target="_self">Drumstick tempor</a></h4>
                                                                <div class="price">$75.00</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Balltip nullaelit">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/6.jpg') !!}" class="img-1 img-responsive" alt="image">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/7.jpg') !!}" class="img-2 img-responsive" alt="image">
                                                                </a>
                                                            </div>
                                                            <div class="box-label"> <span class="label-product label-new"> New </span></div>
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="rating">    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                </div>
                                                                <h4><a href="product.html" title="Balltip nullaelit" target="_self">Balltip nullaelit</a></h4>
                                                                <div class="price">$80.00</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ltabs-item">
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Ribeye hamhock">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/7.jpg') !!}" class="img-1 img-responsive" alt="image">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/6.jpg') !!}" class="img-2 img-responsive" alt="image">
                                                                </a>
                                                            </div>
                                                            <div class="box-label"> <span class="label-product label-sale"> -7% </span></div>
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="rating">    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                </div>
                                                                <h4><a href="product.html" title="Ribeye hamhock" target="_self">Ribeye hamhock</a></h4>
                                                                <div class="price"> <span class="price-new">$65.00</span>
                                                                    <span class="price-old">$70.00</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Wamboudin ribeye">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/8.jpg') !!}" class="img-1 img-responsive" alt="image">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/5.jpg') !!}" class="img-2 img-responsive" alt="image">
                                                                </a>
                                                            </div>
                                                            
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="rating">    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                </div>
                                                                <h4><a href="product.html" title="Wamboudin ribeye" target="_self">Wamboudin ribeye</a></h4>
                                                                <div class="price">$63.00</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ltabs-item">
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Lamboudin ribeye">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/9.jpg') !!}" class="img-1 img-responsive" alt="image">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/4.jpg') !!}" class="img-2 img-responsive" alt="image">
                                                                </a>
                                                            </div>
                                                            
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="rating">    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                </div>
                                                                <h4><a href="product.html" title="Lamboudin ribeye" target="_self">Lamboudin ribeye</a></h4>
                                                                <div class="price">$63.00</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Ribeye hamhock">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/10.jpg') !!}" class="img-1 img-responsive" alt="image">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/3.jpg') !!}" class="img-2 img-responsive" alt="image">
                                                                </a>
                                                            </div>
                                                            <div class="box-label"> <span class="label-product label-sale"> -7% </span></div>
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="rating">    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                </div>
                                                                <h4><a href="product.html" title="Ribeye hamhock" target="_self">Ribeye hamhock</a></h4>
                                                                <div class="price"> <span class="price-new">$65.00</span>
                                                                    <span class="price-old">$70.00</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>                                    
                                            </div>
                                            <div class="ltabs-item">
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Kielbasa hamburg">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/11.jpg') !!}" class="img-1 img-responsive" alt="Pastrami bacon">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/2.jpg') !!}" class="img-2 img-responsive" alt="Pastrami bacon">
                                                                </a>
                                                            </div>
                                                            
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="rating">    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                </div>
                                                                <h4><a href="product.html" title="Drumstick tempor" target="_self">Drumstick tempor</a></h4>
                                                                <div class="price">$75.00</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Balltip nullaelit">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/12.jpg') !!}" class="img-1 img-responsive" alt="image">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/1.jpg') !!}" class="img-2 img-responsive" alt="image">
                                                                </a>
                                                            </div>
                                                            <div class="box-label"> <span class="label-product label-new"> New </span></div>
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="rating">    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                    <span class="fa fa-stack"><i class="fa fa-star fa-stack-2x"></i></span>
                                                                </div>
                                                                <h4><a href="product.html" title="Balltip nullaelit" target="_self">Balltip nullaelit</a></h4>
                                                                <div class="price">$80.00</div>
                                                            </div>
                                                        </div>
                                                     </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ltabs-items items-category-18 grid" data-total="16">
                                        <div class="ltabs-loading"></div>
                                        
                                    </div>
                                    <div class="ltabs-items  items-category-25 grid" data-total="16">
                                        <div class="ltabs-loading"></div>
                                    </div>
                                    <!--End Items-->
                                </div>
                            </div>   
                        </div>
                    </div>
                    <!-- end Listing tabs -->
                    <!--banners 7-->
                    <div class="banners banners7">
                        <div class="row">
                            <div class="banner1 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <div class="b1">
                                    <a href="#">
                                        <img src="{!!asset('front/image/catalog/banners/banner8.jpg') !!}" alt="image">
                                    </a>
                                </div>
                                <div class="b2">
                                    <a href="#">
                                        <img src="{!!asset('front/image/catalog/banners/banner9.jpg') !!}" alt="image">
                                    </a>
                                </div>
                            </div>
                            <div class="banner2 col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                <a href="#">
                                    <img src="{!!asset('front/image/catalog/banners/banner10.jpg') !!}" alt="image">
                                </a>
                            </div>
                            <div class="banner3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <div class="b1">
                                    <a href="#">
                                        <img src="{!!asset('front/image/catalog/banners/banner11.jpg') !!}" alt="image">
                                    </a>
                                </div>
                                <div class="b2">
                                    <a href="#">
                                        <img src="{!!asset('front/image/catalog/banners/banner12.jpg') !!}" alt="image">
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Listing tabs custom -->
                    <div class="module listingtab1-custom listingtab-layout1">
                        <h3 class="modtitle"><span>New items</span></h3>
                        <div id="so_listing_tabs_2" class="so-listing-tabs first-load">
                            <div class="loadeding"></div>
                            <div class="ltabs-wrap">
                                <div class="ltabs-tabs-container" data-delay="300" data-duration="600" data-effect="starwars" data-ajaxurl="" data-type_source="0" data-lg="1" data-md="1" data-sm="1" data-xs="1" data-margin="0">
                                    <!--Begin Tabs-->                            
                                    <div class="ltabs-tabs-wrap">   
                                        <span class='ltabs-tab-selected'></span>
                                        <span class="ltabs-tab-arrow">▼</span>
                                        <ul class="ltabs-tabs cf list-sub-cat font-title">                                  
                                            <li class="ltabs-tab tab-sel" data-category-id="51" data-active-content=".items-category-51"><span class="ltabs-tab-label">Bathroom</span></li>
                                            <li class="ltabs-tab  " data-category-id="52" data-active-content=".items-category-52">   <span class="ltabs-tab-label">Bedroom</span></li>
                                            <li class="ltabs-tab  " data-category-id="53" data-active-content=".items-category-53">   <span class="ltabs-tab-label">Decor</span></li>                                                
                                        </ul>
                                    </div>
                                    <!-- End Tabs-->
                                </div>
                                <div class="ltabs-items-container products-list grid">
                                    <!--Begin Items-->
                                    <div class="ltabs-items ltabs-items-selected items-category-51" data-total="14">
                                        <div class="ltabs-items-inner ltabs-slider">
                                            <!-- item listing tab -->
                                            <div class="ltabs-item">
                                                <div class="item-inner product-layout transition product-grid first-item">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Pastrami bacon">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/funiture/10.jpg') !!}" class="img-1 img-responsive" alt="Pastrami bacon">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/funiture/9.jpg') !!}" class="img-2 img-responsive" alt="Pastrami bacon">
                                                                </a>
                                                            </div>
                                                            
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="price">$42.00</div>
                                                                <h4><a href="product.html" title="Pastrami bacon" target="_self">Pastrami bacon</a></h4>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Chicken swinesha">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/15.jpg') !!}" class="img-1 img-responsive" alt="image">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/2.jpg') !!}" class="img-2 img-responsive" alt="image">
                                                                </a>
                                                            </div>
                                                            <div class="box-label"> <span class="label-product label-sale"> -16% </span></div>
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="price"> <span class="price-new">$46.00</span>
                                                                    <span class="price-old">$55.00</span>
                                                                </div>
                                                                <h4><a href="product.html" title="Chicken swinesha" target="_self">Chicken swinesha</a></h4>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Kielbasa hamburg">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/14.jpg') !!}" class="img-1 img-responsive" alt="Pastrami bacon">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/3.jpg') !!}" class="img-2 img-responsive" alt="Pastrami bacon">
                                                                </a>
                                                            </div>
                                                            <div class="box-label"> <span class="label-product label-new"> New </span></div>
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="price">$55.00</div>
                                                                <h4><a href="product.html" title="Kielbasa hamburg" target="_self">Kielbasa hamburg</a></h4>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Sausage cowbee">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/13.jpg') !!}" class="img-1 img-responsive" alt="image">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/4.jpg') !!}" class="img-2 img-responsive" alt="image">
                                                                </a>
                                                            </div>
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>       
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="price">$60.00</div>
                                                                <h4><a href="product.html" title="Sausage cowbeea" target="_self">Sausage cowbee</a></h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Kielbasa hamburg">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/12.jpg') !!}" class="img-1 img-responsive" alt="Pastrami bacon">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/5.jpg') !!}" class="img-2 img-responsive" alt="Pastrami bacon">
                                                                </a>
                                                            </div>
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                               
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="price">$75.00</div>
                                                                <h4><a href="product.html" title="Drumstick tempor" target="_self">Drumstick tempor</a></h4>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Balltip nullaelit">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/11.jpg') !!}" class="img-1 img-responsive" alt="image">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/6.jpg') !!}" class="img-2 img-responsive" alt="image">
                                                                </a>
                                                            </div>
                                                            <div class="box-label"> <span class="label-product label-new"> New </span></div>
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="price">$80.00</div>
                                                                <h4><a href="product.html" title="Balltip nullaelit" target="_self">Balltip nullaelit</a></h4>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="item-inner product-layout transition product-grid">
                                                    <div class="product-item-container">
                                                        <div class="left-block">
                                                            <div class="product-image-container second_img">
                                                                <a href="product.html" target="_self" title="Lamboudin ribeye">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/10.jpg') !!}" class="img-1 img-responsive" alt="image">
                                                                    <img src="{!!asset('front/image/catalog/demo/product/270/7.jpg') !!}" class="img-2 img-responsive" alt="image">
                                                                </a>
                                                            </div>
                                                            
                                                            <div class="button-group so-quickview cartinfo--left">
                                                                <button type="button" class="addToCart btn-button" title="Add to cart" onclick="cart.add('60 ');">  <i class="fa fa-shopping-basket"></i>
                                                                    <span>Add to cart </span>   
                                                                </button>
                                                                <button type="button" class="wishlist btn-button" title="Add to Wish List" onclick="wishlist.add('60');"><i class="fa fa-heart"></i><span>Add to Wish List</span>
                                                                </button>
                                                                <button type="button" class="compare btn-button" title="Compare this Product " onclick="compare.add('60');"><i class="fa fa-refresh"></i><span>Compare this Product</span>
                                                                </button>
                                                                <!--quickview-->                                                      
                                                                <a class="iframe-link btn-button quickview quickview_handler visible-lg" href="quickview.html" title="Quick view" data-fancybox-type="iframe"><i class="fa fa-eye"></i><span>Quick view</span></a>                                                        
                                                                <!--end quickview-->
                                                            </div>
                                                        </div>
                                                        <div class="right-block">
                                                            <div class="caption">
                                                                <div class="price">$63.00</div>
                                                                <h4><a href="product.html" title="Lamboudin ribeye" target="_self">Lamboudin ribeye</a></h4>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ltabs-items items-category-52 grid" data-total="14">
                                        <div class="ltabs-loading"></div>
                                        
                                    </div>
                                    <div class="ltabs-items  items-category-53 grid" data-total="14">
                                        <div class="ltabs-loading"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end Listing tabs custom -->           
                </div>
                <div class="slider-brands col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="yt-content-slider contentslider" data-autoplay="no" data-delay="4" data-speed="0.6" data-margin="0" data-items_column0="8" data-items_column1="6" data-items_column2="3" data-items_column3="2" data-items_column4="1" data-arrows="yes"
                            data-pagination="no" data-lazyload="yes" data-loop="no">
                        <div class="item">
                            <a href="#">
                                <img src="{!!asset('front/image/catalog/brands/b1.png') !!}" alt="brand">
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="{!!asset('front/image/catalog/brands/b2.png') !!}" alt="brand">
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="{!!asset('front/image/catalog/brands/b3.png') !!}" alt="brand">
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="{!!asset('front/image/catalog/brands/b4.png') !!}" alt="brand">
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="{!!asset('front/image/catalog/brands/b5.png') !!}" alt="brand">
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="{!!asset('front/image/catalog/brands/b6.png') !!}" alt="brand">
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="{!!asset('front/image/catalog/brands/b4.png') !!}" alt="brand">
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="{!!asset('front/image/catalog/brands/b5.png') !!}" alt="brand">
                            </a>
                        </div>
                        <div class="item">
                            <a href="#">
                                <img src="{!!asset('front/image/catalog/brands/b6.png') !!}" alt="brand">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- //Main Container -->
    <!-- Footer Container -->
    <footer class="footer-container typefooter-1">
        <section class="footer-top">
            <div class="container ftop">
                <div class="row">
                    <div class="col-lg-8 col-md-7 col-sm-12 col-xs-12 ">
                        <div class="module newsletter-footer1">
                            <div class="newsletter" style="width:100%   ; background-color: #fff ; ">
                                <div class="title-block">
                                    <div class="page-heading font-title">
                                        Signup for Newsletter
                                    </div>
                                    <div class="promotext">We’ll never share your email address with a third-party. </div>
                                </div>
                                <div class="block_content">
                                    <form method="post" id="signup" name="signup" class="form-group form-inline signup send-mail">
                                        <div class="form-group">
                                            <div class="input-box">
                                                <input type="email" placeholder="Your email address..." value="" class="form-control" id="txtemail" name="txtemail" size="55">
                                            </div>
                                            <div class="subcribe">
                                                <button class="btn btn-primary btn-default font-title" type="submit" onclick="return subscribe_newsletter();" name="submit">
                                            Subscribe
                                        </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-5 col-sm-12 col-xs-12 ">
                        <ul class="socials">
                            <li class="facebook"><a class="_blank" href="https://www.facebook.com/gechchouonline/" target="_blank"><i class="fa fa-facebook"></i><span>Facebook</span></a></li>
                            <li class="twitter"><a class="_blank" href="#" target="_blank"><i class="fa fa-twitter"></i><span>Twitter</span></a></li>
                            <li class="google_plus"><a class="_blank" href="#" target="_blank"><i class="fa fa-google-plus"></i><span>Google Plus</span></a></li>
                            <li><a class="_blank" href="#" target="_blank"><i class="fa fa-linkedin"></i><span>Linkedin</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <!-- /Footer Top Container -->
        <div class="footer-middle ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-style">
                        <div class="infos-footer module">
                            <h3 class="modtitle">GECH CHOU</h3>
                          <!--   <a href="#"><img src="{!!asset('front/image/catalog/logo-footer.png') !!}" alt="image"></a> -->
                            <ul class="menu">
                                <li class="adres">
                                    San Luis potosí, centro historico, 78000 san luis potosí, SPL, Mexico
                                </li>
                                <li class="phone">
                                    (+0214)0 315 215 - (+0214)0 315 215
                                </li>
                                <li class="mail">
                                    <a href="mailto:contact@opencartworks.com">contact@opencartworks.com</a>
                                </li>
                                <li class="time">
                                    Open time: 8:00AM - 6:00PM
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-12 col-style">
                        <div class="box-information box-footer">
                            <div class="module clearfix">
                                <h3 class="modtitle">Information</h3>
                                <div class="modcontent">
                                    <ul class="menu">
                                        <li><a href="#">About Us</a></li>
                                        <li><a href="#">FAQ</a></li>
                                        <li><a href="#">Warranty And Services</a></li>
                                        <li><a href="#">Support 24/7 page</a></li>
                                        <li><a href="#">Product Registration</a></li>
                                        <li><a href="#">Product Support</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-12 col-style">
                        <div class="box-account box-footer">
                            <div class="module clearfix">
                                <h3 class="modtitle">My Account</h3>
                                <div class="modcontent">
                                    <ul class="menu">
                                        <li><a href="#">Brands</a></li>
                                        <li><a href="#">Gift Certificates</a></li>
                                        <li><a href="#">Affiliates</a></li>
                                        <li><a href="#">Specials</a></li>
                                        <li><a href="#">FAQs</a></li>
                                        <li><a href="#">Custom Link</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-4 col-xs-12 col-style">
                        <div class="box-service box-footer">
                            <div class="module clearfix">
                                <h3 class="modtitle">Services</h3>
                                <div class="modcontent">
                                    <ul class="menu">
                                        <li><a href="#">Contact Us</a></li>
                                        <li><a href="#">Returns</a></li>
                                        <li><a href="#">Support</a></li>
                                        <li><a href="#">Site Map</a></li>
                                        <li><a href="#">Customer Service</a></li>
                                        <li><a href="#">Custom Link</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-style">
                        <div class="module box-footer so-instagram-gallery-ltr">
                            <h4 class="modtitle">OUR FACEBOOK PAGE</h4>
                            <div class="modcontent">
                                <div id="fb-root"></div>
                                <script>(function(d, s, id) {
                                  var js, fjs = d.getElementsByTagName(s)[0];
                                  if (d.getElementById(id)) return;
                                  js = d.createElement(s); js.id = id;
                                  js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.12&appId=1934179136895918&autoLogAppEvents=1';
                                  fjs.parentNode.insertBefore(js, fjs);
                                }(document, 'script', 'facebook-jssdk'));</script>
                                <div class="fb-page" data-href="https://www.facebook.com/gechchouonline/"  data-hide-cover="false" data-show-facepile="true"></div> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer Bottom Container -->
        <div class="footer-bottom ">
            <div class="container">
                <div class="copyright">
                   © 2017 Gech Chou Import Export. All Rights Reserved.
                </div>
            </div>
        </div>
        <div class="back-to-top"><i class="fa fa-angle-up"></i></div>
    </footer>
    <!-- //end Footer Container -->
    </div>
  
    {!! Html::script('front/js/jquery-2.2.4.min.js') !!}
    {!! Html::script('front/js/bootstrap.min.js') !!}
    {!! Html::script('front/js/owl-carousel/owl.carousel.js') !!}
    {!! Html::script('front/js/themejs/libs.js') !!}
    {!! Html::script('front/js/unveil/jquery.unveil.js') !!}
    {!! Html::script('front/js/countdown/jquery.countdown.min.js') !!}
    {!! Html::script('front/js/dcjqaccordion/jquery.dcjqaccordion.2.8.min.js') !!}
    {!! Html::script('front/js/datetimepicker/moment.js') !!}
    {!! Html::script('front/js/datetimepicker/bootstrap-datetimepicker.min.js') !!}
    {!! Html::script('front/js/jquery-ui/jquery-ui.min.js') !!}
    {!! Html::script('front/js/modernizr/modernizr-2.6.2.min.js') !!}
    {!! Html::script('front/js/minicolors/jquery.miniColors.min.js') !!}
   
    {!! Html::script('front/js/themejs/application.js') !!}
    {!! Html::script('front/js/themejs/homepage.js') !!}
    {!! Html::script('front/js/themejs/toppanel.js') !!}
    {!! Html::script('front/js/themejs/so_megamenu.js') !!}
    {!! Html::script('front/js/themejs/addtocart.js') !!}
    {!! Html::script('front/js/themejs/cpanel.js') !!}
</body>
</html>