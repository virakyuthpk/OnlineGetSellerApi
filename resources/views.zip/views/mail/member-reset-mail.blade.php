Hello.<br><br>

You recently requested to reset your password <br><br>

Here is the new password <br><br>

<a href="{{route('member-confirm-reset',$token)}}">Click link to reset password</a>