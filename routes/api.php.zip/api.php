<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::group([
    'middleware' => ['api', 'cors','throttle:60,1',
    'bindings'],
    'prefix' => '',
], function ($router) {

	// get online product
	Route::get('/onlineGet', 'ApiController@onlineGet');

	// get official store
	Route::get('/officailStore', 'ApiController@officailStore');

	// get populare store
	Route::get('/popular', 'ApiController@popular');

	// get collection store
	Route::get('/collection', 'ApiController@collection');

	// get toabao collection
	Route::get('/toabaoCollection', 'ApiController@toabaoCollection');

	// get category
	Route::get('/category', 'ApiController@category');

	// get brand
	Route::get('/brand', 'ApiController@brand');

	/// get all category
	Route::get('/allCategory', 'ApiController@allCategory');

	// list product
	Route::get('/listProduct/{id}', 'ApiController@listProduct');

	Route::get('/listAllProduct', 'ApiController@listAllProduct');

	Route::get('/getPolicies', 'ApiController@getPolicies');
	
	Route::get('/getHelp', 'ApiController@getHelp');


});