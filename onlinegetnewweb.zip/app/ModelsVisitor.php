<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ModelsVisitor extends Model
{
    //
}
