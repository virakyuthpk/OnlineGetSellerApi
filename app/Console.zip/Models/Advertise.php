<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Advertise extends Model
{
    protected $table = 'advertises';

    public static function insert($value,$id,$filename){
        $link = $value['link'];
        $position = $value['position'];
        if($id  == null){
            $ad = new Advertise();
            $ad->link = $link;
            $ad->position = $position;
            $ad->image = $filename;
            $ad->status = 1;
            $ad->save();
        }else{
        	Advertise::where('id',$id)->update(array(
				'link' 	  =>  $link,
				'position' =>  $position,
				'image' => $filename,
				'status' => 1,
			));
        }
    }
}
