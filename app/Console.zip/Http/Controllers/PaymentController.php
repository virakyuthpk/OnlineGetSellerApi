<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

class PaymentController extends Controller
{
    public function redirect(){
        return view('wing_form');
    }
    public function store(){
        $getData = Input::all();
        // $data = response()->json($getData);
        $data = json_encode($getData);

        // $jsondata = [
        //     "username" => $data->username,
        //     "bill_till_rbtn" =>$data->bill_till_rbtn,
        //     "bill_till_number" =>$data->bill_till_number,
        //     "sandbox" =>$data->sandbox,
        //     "rest_api_key" =>$data->rest_api_key,
        //     "wing_account" =>$data->wing_account,
        //     "amount"=>$data->amount,
        //     "attr1_name"=>$data->attr1_name,
        //     "attr1_value"=>$data->artt1_value,
        //     "attr2_name"=>$data->attr2_name,
        //     "attr2_value"=>$data->artt2_value,
        //     "return_url"=>$data->return_url,
        //     "remark"=>$data->remark,
        //     "_token"=>$data->_token
        // ];
        // return $data;

        // return $data;
        // return (Input::all());
        // return redirect()->away('https://wingsdk.wingmoney.com')->with('data', $data);
        // return redirect()->away('https://wingsdk.wingmoney.com')->with(Input::all());
        return view('outdata')->with('data', $data);

    }
//     public function authenticateTEST(Request $request)
//     {
//         $loginId = $request->input('loginId');
//         $password = $request->input('password');
//         $item = $request->input('item');
//         $amount = $request->input('amount');
//         $merchant_name = $request->input('merchant_name');
//         $notify_service = $request->input('notify_service');
//         $notify_url = $request->input('notify_url');
//         $return_url = $request->input('return_url');
//         // $param = array(
//         //     'loginId'=>'online.bungech',
//         //     'password' =>'f6a5be9eb57648de70b0b50297047dc5',
//         //     'item'=>'ITEMS 001',
//         //     'amount'=>25,
//         //     'merchant_name'=>'Onlineget',
//         //     'notify_service'=>'http://sampleLink/notifyservice.php',
//         //     'notify_url'=>'http://sampleLink/notify.php',
//         //     'return_url'=>'localhost:8000' 
//         //     );
//         return [
//             'data' => [
//                 'loginId'=>$loginId,
//                 'password' =>$password,
//                 'item'=>$item,
//                 'amount'=>$amount,
//                 'merchant_name'=>$merchant_name,
//                 'notify_service'=>$notify_service,
//                 'notify_url'=>$notify_url,
//                 'return_url'=>$return_url
//             ],
//         ];
//         // return redirect('https://wingsdk.wingmoney.com:334/')->with('user data', $param);
//     }
//     public function wingPay(Request $request)
//     {
//         $param = [
//             'loginId' => $request->input('loginId'),
//             'password' => $request->input('password'),
//             'item' => $request->input('item'),
//             'amount' => $request->input('amount'),
//             'merchant_name' => $request->input('merchant_name'),
//             'notify_service' => $request->input('notify_service'),
//             'notify_url' => $request->input('notify_url'),
//             'return_url' => $request->input('return_url')
//         ];

//         return redirect('https://wingsdk.wingmoney.com');
//     }



// /*------------------------ send data ---------------------------*/
// public function authenticate()
// {
//     $param = array(
//         // 'loginId'=>'online.bungech',
//         'loginId'=>'onlineget.com',
//         'password' =>'f6a5be9eb57648de70b0b50297047dc5',
//         'item'=>'ITEMS 001',
//         'amount'=>25,
//         'merchant_name'=>'Onlineget',
//         'notify_service'=>'localhost:8000',
//         'notify_url'=>'localhost:8000',
//         'return_url'=>'localhost:8000',
//         'order_refereno'=>'back'
//     );
//     // return $param;
//     $url = "https://110.74.218.219/onlinepay/wing/authenticate";
//     $content = json_encode($param);
//     $curl = curl_init($url);
//     curl_setopt($curl, CURLOPT_HEADER, false);
//     curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
//     curl_setopt($curl, CURLOPT_HTTPHEADER, array("Content-type: application/json"));
//     curl_setopt($curl, CURLOPT_POST, true);
//     curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
//     curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
//     $response = curl_exec($curl);
//     if ($response===FALSE){
//         return"cURL Error: ".curl_error($curl);
//     }
//     else{
//         return redirect()->to('https://wingsdk.wingmoney.com');
//         // header("Location:https://wingsdk.wingmoney.com?token=$response");
//     }
// }
//     // $param = array(
//     //     'loginId'=>'YOUR_LOGIN_ID',
//     //     'password' =>'YOUR_PASSWORD',
//     //     'item'=>'ITEMS 001',
//     //     'amount'=>25,
//     //     'merchant_name'=>'YOUR COMPANY NAME',
//     //     'notify_service'=>'http://sampleLink/notifyservice.php',
//     //     'notify_url'=>'http://sampleLink/notify.php',
//     //     'return_url'=>'http://sampleLink/yourshop.php'
//     // );
// /*------------------------ end ---------------------------*/

// /*------------------------ get token by redirecting to wing site ---------------------------*/
//     // $url = "https://110.74.218.219/onlinepay/wing/authenticate";
//     // $content = json_encode($param);
//     // $curl = curl_init($url);
//     // curl_setopt($curl, CURLOPT_HEADER, false);
//     // curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
//     // curl_setopt($curl, CURLOPT_HTTPHEADER, array("Content-type: application/json"));
//     // curl_setopt($curl, CURLOPT_POST, true);
//     // curl_setopt($curl, CURLOPT_POSTFIELDS, $content);
//     // curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
//     // $response = curl_exec($curl);
//     // if ($response===FALSE)
//     // echo"cURL Error: ".curl_error($curl);
//     // elseheader("Location:
//     // https://110.74.218.219/onlinepay/payment?token=$response");

// /*------------------------ end ---------------------------*/


}
