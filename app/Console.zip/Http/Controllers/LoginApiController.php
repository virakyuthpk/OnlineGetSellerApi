<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Model\User; 
use App\User as Authuser;
use Illuminate\Support\Facades\Validator;
use Socialite;
use App\Models\UserHelp;
class LoginApiController extends Controller
{
    public $URL = 'http://onlineget.com';
    public function redirectToProvider()
    {
        return Socialite::driver('facebook')->redirect();
    }
    public function handleProviderCallback()
    {
        $user = Socialite::driver('facebook')->stateless()->user();
           return json_encode([
          'data'=> [
            'id' => (int) $user->id,
            'username' => $user->name, 
            'email' => $user->email,
            'token' => (string) $user->token, 
            'avatar' => $user->avatar
          ],
        ]);  
    }

    public function redirectToGoogle()
    {
        return Socialite::driver('google')->redirect();
    }
    public function handleGoogleCallback()
    {
        $user = Socialite::driver('google')->stateless()->user();
        return json_encode([
          'data'=> [
            'id' => (int) $user->id,
            'username' => $user->name, 
            'email' => $user->email,
            'token' => (string) $user->token, 
            'avatar' => $user->avatar
          ],
        ]);  
    }
    public function userhelp(){
        try {
            $data['helps'] = UserHelp::where('status',1)->select('id','title','des')->get();
            foreach ($data['helps'] as  $help) {
                $help->des = UserHelp::where('id',$help->id)->first()->des;
                if ($help->image == "1") {
                    $help->img = $help->image == "1" ? $this->URL . '/uploads/helps/' . $help->id .'.jpg': $this->URL . '/uploads/default-img.jpg';
                }else if($help->image == "0"){
                    $help->img = $this->URL . '/uploads/default-img.jpg';
                }else{
                    $help->img = $this->URL . '/uploads/helps/' . $help->image;
                }
            }
            return response()->json($data);
        } catch (Exception $e) {
            
        }
    }
}
