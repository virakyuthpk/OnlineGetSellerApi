<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Brand; 
use App\Models\Unit;
use App\Models\Product;
use App\Models\Variant;
use App\Models\Discount;
use App\Models\Category;
use App\Models\District;
use App\Models\Commune;
use App\Models\Supplier;
use App\Models\Gallery;
use App\Models\Page;
use App\Models\Product_varaint;
use App\Http\Controllers\Controller;
use App\Models\Campaign;
use Cart;
use App\Models\Orders;

class ApiController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function onlineGet(){
    	$data['product'] = Product::inRandomOrder()->take(3)->get();
	     foreach ($data['product'] as  $pro) {
	        $pro->supplier = Supplier::where('id',$pro->supplier_id)->first();
	        $pro->unit = Unit::where('id',$pro->unit_id)->first();
	        $pro->category = Category::where('id',$pro->category_id)->first();
	     }
    	return response()->json($data);
    }

    public function officailStore(){
    	$data['product'] = Product::inRandomOrder()->take(3)->get();
	     foreach ($data['product'] as  $pro) {
	        $pro->supplier = Supplier::where('id',$pro->supplier_id)->first();
	        $pro->unit = Unit::where('id',$pro->unit_id)->first();
	        $pro->category = Category::where('id',$pro->category_id)->first();
	     }
    	return response()->json($data);
    }

    public function popular(){
    	$data['popular'] = Orders::select('orders.product_id', 'products.name_en', 'products.image')
        ->join('products', 'products.id', 'orders.product_id')
        ->groupBy('orders.product_id','products.name_en', 'products.image')
        ->take(4)
        ->get();
	     foreach ($data['popular'] as  $pro) {
	        $pro->count = Product::where('id',$pro->product_id)->count();
	     }
    	return response()->json($data);
    }

    public function collection(){
    	$data['product'] = Product::inRandomOrder()->take(3)->get();
	     foreach ($data['product'] as  $pro) {
	        $pro->supplier = Supplier::where('id',$pro->supplier_id)->first();
	        $pro->unit = Unit::where('id',$pro->unit_id)->first();
	        $pro->category = Category::where('id',$pro->category_id)->first();
	     }
    	return response()->json($data);
    }

    public function toabaoCollection(){
    	$data['product'] = Product::inRandomOrder()->take(4)->get();
	     foreach ($data['product'] as  $pro) {
	        $pro->supplier = Supplier::where('id',$pro->supplier_id)->first();
	        $pro->unit = Unit::where('id',$pro->unit_id)->first();
	        $pro->category = Category::where('id',$pro->category_id)->first();
	     }
    	return response()->json($data);
    }

    public function category(){
    	$data = Category::all();
	     
    	return response()->json($data);
    }

    public function brand(){
		$data = Brand::get();
		return response()->json($data);
    }

    public function allCategory()
    {
        $data = Category::get();

        return response()->json($data);
    }

    public function listProduct($id){
        $data['product'] = Product::where('category_id', $id)->get();
         foreach ($data['product'] as  $pro) {
            $pro->supplier = Supplier::where('id',$pro->supplier_id)->first();
            $pro->unit = Unit::where('id',$pro->unit_id)->first();
            $pro->category = Category::where('id',$pro->category_id)->first();
         }
        return response()->json($data);
    }

    public function listAllProduct(){
        $data['product'] = Product::take(20)->get();
         foreach ($data['product'] as  $pro) {
            $pro->supplier = Supplier::where('id',$pro->supplier_id)->first();
            $pro->unit = Unit::where('id',$pro->unit_id)->first();
            $pro->category = Category::where('id',$pro->category_id)->first();
         }
        return response()->json($data);
    }

    public function getPolicies(){
        $data = Page::where('id', 3)->first();
        return response()->json($data);
    }

    public function getHelp(){
        $data = Page::where('id', 1)->first();
        return response()->json($data);
    }

}
